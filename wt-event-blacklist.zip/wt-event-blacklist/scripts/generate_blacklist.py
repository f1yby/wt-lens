#!/usr/bin/env python3
"""
生成 War Thunder 活动车黑名单

分析 wpcost.blkx 和 statshark 数据，找出需要过滤的限时活动车辆
"""

import json
import re
from pathlib import Path


def load_wpcost(datamine_path: Path) -> dict:
    """加载 wpcost.blkx 数据"""
    wpcost_file = datamine_path / "char.vromfs.bin_u" / "config" / "wpcost.blkx"
    with open(wpcost_file, 'r') as f:
        return json.load(f)


def load_statshark(raw_path: Path, filename: str) -> dict:
    """加载 statshark 数据"""
    statshark_file = raw_path / filename
    with open(statshark_file, 'r') as f:
        data = json.load(f)
    
    # 合并所有模式的数据
    vehicle_stats = data.get('vehicle_stats', {})
    all_vehicles = {}
    for mode in ['arcade', 'historical', 'simulation']:
        for v in vehicle_stats.get(mode, []):
            vid = v.get('name')
            if vid:
                all_vehicles[vid] = v
    return all_vehicles


def is_ground_vehicle(unit_class: str) -> bool:
    """检查是否为地面载具"""
    return unit_class in {
        'exp_tank', 'exp_heavy_tank', 'exp_light_tank',
        'exp_tank_destroyer', 'exp_SPAA'
    }


def analyze_event_vehicles(wpcost: dict, statshark: dict) -> dict:
    """
    分析活动车辆数据
    
    返回按后缀分类的活动车统计信息
    """
    categories = {
        '_event': [],
        '_tutorial': [],
        '_race': [],
        '_snowball': [],
        '_football': [],
        '_yt_cup': [],
    }
    
    for vid, data in wpcost.items():
        if not isinstance(data, dict):
            continue
        
        unit_class = data.get('unitClass', '')
        if not is_ground_vehicle(unit_class):
            continue
        
        # 检查各种活动车后缀
        for suffix in categories.keys():
            if vid.endswith(suffix) or (suffix == '_yt_cup' and '_yt_cup_' in vid):
                ts_data = statshark.get(vid, {})
                kills = ts_data.get('ground_kills', 0) or 0
                games = ts_data.get('games', 0) or 0
                value = data.get('value', 0)
                show_only = data.get('showOnlyWhenBought', False)
                
                categories[suffix].append({
                    'vid': vid,
                    'kills': kills,
                    'games': games,
                    'value': value,
                    'show_only': show_only
                })
                break
    
    return categories


def generate_patterns(categories: dict) -> list:
    """
    生成正则表达式黑名单模式
    
    基于分析结果生成 EVENT_VEHICLE_PATTERNS 列表
    """
    patterns = []
    
    # 标准后缀模式
    suffix_map = {
        '_event': r'_event$',
        '_tutorial': r'_tutorial$',
        '_race': r'_race$',
        '_snowball': r'_snowball$',
        '_football': r'_football$',
        '_yt_cup': r'_yt_cup_\d{4}$',
    }
    
    for suffix, pattern in suffix_map.items():
        if categories.get(suffix):
            patterns.append(pattern)
    
    return patterns


def print_analysis(categories: dict):
    """打印分析结果"""
    print("=" * 60)
    print("War Thunder 活动车黑名单分析")
    print("=" * 60)
    
    total = sum(len(v) for v in categories.values())
    print(f"\n总计发现 {total} 辆活动车\n")
    
    for suffix, vehicles in categories.items():
        if not vehicles:
            continue
        
        total_kills = sum(v['kills'] for v in vehicles)
        total_games = sum(v['games'] for v in vehicles)
        
        print(f"\n{'='*60}")
        print(f"{suffix} 车辆 ({len(vehicles)}辆)")
        print(f"{'='*60}")
        print(f"总击杀: {total_kills}, 总场次: {total_games}")
        print("\n车辆列表:")
        
        for v in sorted(vehicles, key=lambda x: x['kills'], reverse=True):
            show_flag = "[showOnly]" if v['show_only'] else ""
            print(f"  {v['vid']:<40} kills={v['kills']:>6} games={v['games']:>6} value={v['value']:>8} {show_flag}")


def main():
    """主函数"""
    # 路径配置
    base_path = Path(__file__).parent.parent.parent.parent  # 项目根目录
    datamine_path = base_path / "data" / "datamine"
    raw_path = base_path / "data" / "raw"
    
    # 查找最新的 statshark 文件
    statshark_files = list(raw_path.glob("statshark_diff_*.json"))
    if not statshark_files:
        print("错误: 找不到 statshark 数据文件")
        return
    
    latest_file = sorted(statshark_files)[-1].name
    print(f"使用数据文件: {latest_file}")
    
    # 加载数据
    wpcost = load_wpcost(datamine_path)
    statshark = load_statshark(raw_path, latest_file)
    
    # 分析活动车
    categories = analyze_event_vehicles(wpcost, statshark)
    
    # 打印分析结果
    print_analysis(categories)
    
    # 生成建议的黑名单模式
    patterns = generate_patterns(categories)
    
    print("\n" + "=" * 60)
    print("建议的 EVENT_VEHICLE_PATTERNS 配置")
    print("=" * 60)
    print("\nEVENT_VEHICLE_PATTERNS = [")
    for p in patterns:
        print(f"    r'{p}',")
    print("]")


if __name__ == '__main__':
    main()
