---
name: wt-event-blacklist
description: |
  管理 War Thunder 载具数据中的活动车黑名单。
  当需要识别、添加或更新限时活动车辆过滤规则时使用此 Skill。
  适用于处理 _event, _race, _snowball, _football 等后缀的限时活动车辆。
---

# War Thunder 活动车黑名单管理

## 背景知识

### 什么是活动车

War Thunder 中的活动车（Event Vehicles）是指：
- **限时活动车辆**: 只在特定活动期间可用的载具（如坦克两项、雪球活动）
- **教程车辆**: 仅用于教程模式的载具
- **测试车辆**: 未正式发布的测试载具

### 活动车识别特征

| 特征 | 说明 | 示例 |
|------|------|------|
| `_event` 后缀 | 一般活动车 | `germ_a7v_event` |
| `_race` 后缀 | 坦克两项/赛车活动 | `ussr_t_80u_race` |
| `_snowball` 后缀 | 雪球活动 | `us_m8_scott_snowball` |
| `_football` 后缀 | 足球活动 | `ussr_m551_football` |
| `_yt_cup_YYYY` 后缀 | YouTube Cup | `us_m1a1_abrams_yt_cup_2019` |
| `_tutorial` 后缀 | 教程车辆 | `ussr_t_50_for_tutorial` |

### 常驻金币车 vs 限时活动车

**重要区分**:
- `germ_a7v_event` → 限时活动车（需要过滤）
- `germ_a7v` → 常驻金币车（**不应过滤**）

判断方法：
1. 检查是否有活动后缀
2. 查看 `wpcost.blkx` 中的 `showOnlyWhenBought` 字段
3. 查看 `statshark` 数据中的击杀数（限时活动车在非活动期间击杀数为0）

## 当前黑名单配置

```python
EVENT_VEHICLE_PATTERNS = [
    r'_event$',           # 一般活动车
    r'_tutorial$',        # 教程车辆
    r'_race$',            # 坦克两项/赛车活动车
    r'_snowball$',        # 雪球活动车
    r'_football$',        # 足球活动车
    r'_yt_cup_\d{4}$',    # YouTube Cup 车辆
]
```

## 如何添加新的黑名单规则

### 步骤 1: 识别新类型的活动车

当发现新的活动车类型时：

1. 检查车辆ID后缀模式
2. 在 `wpcost.blkx` 中查看车辆属性
3. 确认该类型车辆是否为限时活动车

### 步骤 2: 运行分析脚本

使用提供的脚本分析活动车数据：

```bash
python3 .codebuddy/skills/wt-event-blacklist/scripts/generate_blacklist.py
```

脚本会：
- 加载最新的 `wpcost.blkx` 和 `statshark` 数据
- 分析各类活动车的击杀数据
- 生成建议的黑名单配置

### 步骤 3: 更新代码中的黑名单

编辑 `data/scripts/fetch_datamine.py`：

1. 找到 `EVENT_VEHICLE_PATTERNS` 列表
2. 添加新的正则表达式模式
3. 保持列表按字母顺序排列

示例 - 添加 `_summer` 后缀：

```python
EVENT_VEHICLE_PATTERNS = [
    r'_event$',
    r'_football$',
    r'_race$',
    r'_snowball$',
    r'_summer$',          # ← 新增
    r'_tutorial$',
    r'_yt_cup_\d{4}$',
]
```

### 步骤 4: 验证更新

运行数据更新脚本，检查是否正确过滤：

```bash
cd data/scripts && python3 fetch_datamine.py
```

## 正则表达式模式参考

| 模式 | 说明 | 匹配示例 |
|------|------|----------|
| `r'_event$'` | 以 `_event` 结尾 | `germ_a7v_event` |
| `r'_race$'` | 以 `_race` 结尾 | `ussr_t_80u_race` |
| `r'_yt_cup_\d{4}$'` | YouTube Cup 年份 | `us_m1a1_abrams_yt_cup_2019` |
| `r'^(vid1|vid2)$'` | 精确匹配特定ID | `us_amx_13_75` |

## 常见问题

### Q: 为什么一战车辆（如 germ_a7v）有击杀数据还要过滤 _event 版本？

A: `germ_a7v` 是常驻金币车（保留），`germ_a7v_event` 是限时活动版本（过滤）。两者是不同的车辆ID。

### Q: 如何确认一辆车是否为限时活动车？

A: 检查以下几点：
1. 车辆ID是否有活动后缀
2. `wpcost.blkx` 中 `showOnlyWhenBought` 是否为 true
3. 非活动期间 `statshark` 击杀数是否为0

### Q: 发现新的活动车类型如何处理？

A: 按照"如何添加新的黑名单规则"部分的步骤操作，先运行分析脚本确认模式，再更新正则表达式。

## 相关文件

- `data/scripts/fetch_datamine.py` - 主脚本，包含黑名单配置
- `data/datamine/char.vromfs.bin_u/config/wpcost.blkx` - 车辆属性数据
- `data/raw/statshark_diff_*.json` - 车辆击杀统计数据
